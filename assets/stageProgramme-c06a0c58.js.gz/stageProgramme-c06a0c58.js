import{d as j,B as Y,A as p,D as A,ao as u,a0 as q,o as f,b as C,g as l,t as v,u as n,S as m,J as N,K as G,h as i,H as O,I as c,at as y,a3 as K,au as Q,$ as W,R as X,p as tt,l as et}from"./vendor-5d3cd767.js";import{a as at}from"./overlay_plugin_api-409cb9ea.js";import{_ as st}from"./index-247be567.js";const ot=g=>(tt("data-v-4bdca458"),g=g(),et(),g),lt=W('<svg xmlns="http://www.w3.org/2000/svg" class="icon clock" width="60" height="70" viewBox="0 0 60 70" fill="none" data-v-4bdca458><path d="M53.5685 11.7169L58.2818 16.4303L53.4385 21.2738C58.2244 27.2645 60.5349 34.8603 59.8954 42.5013C59.256 50.1423 55.7152 57.2485 50.0001 62.3603C44.2851 67.4722 36.8297 70.2018 29.1652 69.9884C21.5006 69.775 14.2086 66.6349 8.7868 61.213C3.36502 55.7911 0.224998 48.499 0.0116294 40.8342C-0.201739 33.1695 2.52774 25.7139 7.63949 19.9988C12.7512 14.2836 19.8572 10.7427 27.4981 10.1033C35.1389 9.46381 42.7346 11.7743 48.7252 16.5603L53.5685 11.7169ZM38.9319 61.5579C44.2831 59.341 48.6184 55.2129 51.0947 49.9765C53.5711 44.7402 54.0113 38.77 52.3298 33.2271C50.6483 27.6841 46.9654 22.9648 41.9972 19.9868C37.0291 17.0089 31.1309 15.9854 25.4499 17.1152C19.7689 18.2451 14.7113 21.4476 11.2606 26.0999C7.80989 30.7522 6.2129 36.5217 6.7802 42.2862C7.34751 48.0507 10.0386 53.3982 14.33 57.2885C18.6213 61.1788 24.2063 63.3339 29.9985 63.3346C33.063 63.3346 36.0974 62.7308 38.9285 61.5579H38.9319ZM33.3319 23.3338V43.3342H26.6652V23.3338H33.3319ZM43.3318 0V6.6668H16.6652V0H43.3318Z" fill="url(#paint0_linear_2392_974)" data-v-4bdca458></path><path d="M53.5685 11.7169L58.2818 16.4303L53.4385 21.2738C58.2244 27.2645 60.5349 34.8603 59.8954 42.5013C59.256 50.1423 55.7152 57.2485 50.0001 62.3603C44.2851 67.4722 36.8297 70.2018 29.1652 69.9884C21.5006 69.775 14.2086 66.6349 8.7868 61.213C3.36502 55.7911 0.224998 48.499 0.0116294 40.8342C-0.201739 33.1695 2.52774 25.7139 7.63949 19.9988C12.7512 14.2836 19.8572 10.7427 27.4981 10.1033C35.1389 9.46381 42.7346 11.7743 48.7252 16.5603L53.5685 11.7169ZM38.9319 61.5579C44.2831 59.341 48.6184 55.2129 51.0947 49.9765C53.5711 44.7402 54.0113 38.77 52.3298 33.2271C50.6483 27.6841 46.9654 22.9648 41.9972 19.9868C37.0291 17.0089 31.1309 15.9854 25.4499 17.1152C19.7689 18.2451 14.7113 21.4476 11.2606 26.0999C7.80989 30.7522 6.2129 36.5217 6.7802 42.2862C7.34751 48.0507 10.0386 53.3982 14.33 57.2885C18.6213 61.1788 24.2063 63.3339 29.9985 63.3346C33.063 63.3346 36.0974 62.7308 38.9285 61.5579H38.9319ZM33.3319 23.3338V43.3342H26.6652V23.3338H33.3319ZM43.3318 0V6.6668H16.6652V0H43.3318Z" fill="white" data-v-4bdca458></path><defs data-v-4bdca458><linearGradient id="paint0_linear_2392_974" x1="0" y1="0" x2="62.1639" y2="69.6625" gradientUnits="userSpaceOnUse" data-v-4bdca458><stop stop-color="white" data-v-4bdca458></stop><stop offset="0.884426" stop-color="white" stop-opacity="0" data-v-4bdca458></stop></linearGradient></defs></svg><aside data-v-4bdca458><span data-v-4bdca458>COMBAT</span><span data-v-4bdca458>TIMELINE</span></aside>',2),nt=ot(()=>l("path",{d:"M16.7974 20.3694C15.1176 21.4034 13.1389 22 11.0205 22C4.93406 22 -7.46378e-07 17.0751 -4.80825e-07 11C-2.15273e-07 4.92487 4.93406 -1.44536e-06 11.0205 -1.17931e-06C12.8556 -1.0991e-06 14.586 0.447694 16.1079 1.23963L37.9014 11.0859L37.7156 11.0908L38 11.0872L16.7974 20.3694ZM4.00746 11C4.00746 14.866 7.14732 18 11.0205 18C14.8937 18 18.0336 14.866 18.0336 11C18.0336 7.13401 14.8937 4 11.0205 4C7.14732 4 4.00747 7.13401 4.00746 11Z",fill:"white"},null,-1)),rt=[nt],it={id:"settings"},ct=j({__name:"stageProgramme",setup(g){const e=Y({list:[],inputRaw:"",style:{}}),S=p(0),x=p(!1),d=p(0),k=p(!0),r=p(0);let _,I;const B=A(()=>({transform:`scale(${e.style.scale})`,"--stage-programme-height":e.style.lineHeight})),h=p(!1),b=/^(P\d|阶段)/,$=A(()=>e.list.length*(e.style.lineHeight-1.5)-5),D=A(()=>{const o=u.duration(d.value,"seconds");return u({h:o.hours(),m:o.minutes(),s:o.seconds()}).format("mm:ss")});function R(){H(),at("onInCombatChangedEvent",z),addEventListener("onOverlayStateUpdate",o=>{k.value=!o.detail.isLocked})}function w(){const o=localStorage.getItem("programmeData"),a=localStorage.getItem("programmeStyle");if(o?e.inputRaw=JSON.parse(o):e.inputRaw=`0 阶段 - 1
00:11.4 "深度污浊" class="AoE"
00:21.6 "双重冲击" class="TankBurster"
00:34.4 "污水泛滥" class="AoE"
阶段 - 2
00:54.4 "吐息飞瀑"
01:10.4 "连贯攻击" class="Shared"
01:33.8 "深度污浊" class="AoE"
01:42.5 "灵水弹" class="Shared"
01:48.3 "震荡波"
02:10.9 "多重刻印" class="Shared"
02:24.3 "展翅飞瀑"
02:47.0 "沟流充溢" class="AoE"
阶段 - 3
03:17.1 "双重冲击" class="TankBurster"
03:27.3 "深度污浊" class="AoE"
03:44.1 "污水泛滥" class="AoE"
03:58.7 "震荡波"
阶段 - 4
04:11.1 "海怪战车" class="AoE"
04:37.0 "双重冲击" class="TankBurster"
04:46.3 "深度污浊" class="AoE"
04:59.9 "沟流溢出" class="AoE"
05:09.1 "污染洪水" class="AoE"
05:24.5 "污染洪水" class="AoE"
05:37.4 "吐息飞瀑"
阶段 - 5
06:00.7 "多重刻印" class="Shared"
06:07.0 "分离"
06:20.9 "展翅飞瀑"
06:38.6 "分离"
06:50.8 "污水喷发"
06:58.2 "污染洪水" class="AoE"
07:05.8 "连贯攻击" class="Shared"
07:28.3 "双重冲击" class="TankBurster"
07:36.5 "深度污浊" class="AoE"
07:54.1 "污水泛滥" class="AoE"
阶段 - 6
08:10.7 "沟流溢出" class="AoE"
08:21.2 "连贯攻击" class="Shared"
08:54.6 "分离"
09:06.9 "污水喷发（狂暴）" class="Enrage"
`,a){const t=JSON.parse(a);t.scale<.5&&(t.scale=1),e.style=Object.assign(e.style,t)}else e.style={scale:1,lineHeight:40,customCSS:`/* 如果设置未生效就加上!important强制最高优先级 */
header {
  width: 360px !important; /* 宽 */
  height: 100px !important; /* 高 */
  border-radius: 8px !important; /* 圆角 */
 } /* 头部 */
header > .clock {  margin-left: 9px !important; } /* 头部左侧时钟svg图标 */
header > aside { /* 两行字 */
    font-size: 36px !important; /* 字体尺寸 */
    margin-left: 7px !important; /* 左基准偏移 */
    span{ /* 每行字 */
      height: 32px !important; /* 高度 */
    }
}
header > article {
  right: 7px !important; /* 右基准偏移 */
  bottom: 0px !important; /* 下基准偏移 */
  font-size: 64px !important; /* 字体尺寸 */
  height: 74px !important; /* 高度 */
  width: 111px !important; /* 宽度 */
  text-align: left !important; /* 文字左对齐 */
} /* 头部右侧计时文字 */
#main { /* 主体 */
  width: 360px !important;  /* 宽度 */
}
#main > ul { /* 整个无序列表 */
  li{ } /* 内部list */
 }
#main > ul .stage { /* 主体的阶段行正文 */
  font-size:18px !important; 
  background-color: rgba(0,0,0,0) !important;
  } 
#main > ul .normal { /* 主体的非阶段行左侧正文 */
  font-size:22px  !important;
  } 
#main > ul .auxiliary { /* 主体的非阶段行右侧时间 */
  font-size:18px  !important; 
  text-shadow:none !important; /* 不应用class的颜色 */
  color:white !important; /* 不应用class的颜色 */
  } 
#main .position{ } /* 主体的左侧箭头svg图标 */
#main > span { /* 主体的左侧装饰线段 */
  left:40px !important; /* 左基准偏移 */
  font-size: 20px !important; /* 字体大小/*
  letter-spacing: 12.625px !important; /* 字符间距 */
  }
:root{
  --color-aoe:rgb(112,48,159); /* 声明aoe颜色变量 */
  --color-tank-burster:rgb(255,75,75); /* 声明死刑颜色变量 */
  --color-shared:rgb(0,112,192); /* 声明分摊颜色变量 */
  --color-enrage:crimson; /* 声明狂暴颜色变量 */
}
.AoE{ /* 对应正文模板字符串内的class AoE */
  /* text-shadow: -1px 0 2px var(--color-aoe), 0 1px 2px var(--color-aoe), 1px 0 2px var(--color-aoe), 0 -1px 2px var(--color-aoe); */
}
.TankBurster{ /* 死刑 */
  /* text-shadow: -1px 0 2px var(--color-tank-burster), 0 1px 2px var(--color-tank-burster), 1px 0 2px var(--color-tank-burster), 0 -1px 2px var(--color-tank-burster); */
}
.Shared{ /* 分摊 */
   /* text-shadow: -1px 0 2px var(--color-shared), 0 1px 2px var(--color-shared), 1px 0 2px var(--color-shared), 0 -1px 2px var(--color-shared); */
}
.Enrage{ /* 狂暴 */
  /* color: var(--color-enrage); */
}
`}}R(),w(),q(()=>{var a;const o=[];[...e.inputRaw.matchAll(/^([ \t\u3000]*(?<time>[:：\d.]+) +)?"?(?<action>.+?)"?(?: *class="(?<className>[^"]+)")?$/gm)].forEach(t=>{var L,M;let s=(L=t.groups)==null?void 0:L.time;if(s!=null&&s.includes(":")){let V=0;s!=null&&s.includes(".")&&(V=Number(s.substr(s.lastIndexOf(".")+1)/10),s=s.substring(0,s.lastIndexOf("."))),s=u.duration(s).as("seconds")/60+V}else s=s?Number(s):null;const E=u.duration(s,"seconds"),P=u({h:E.hours(),m:E.minutes(),s:E.seconds()}).format("mm:ss");o.push({text:t.groups.action,timeSeconds:(s==null?void 0:s.toFixed(1))??null,timeFormat:P,className:((M=t==null?void 0:t.groups)==null?void 0:M.className)??""})}),e.list=o,localStorage.setItem("programmeData",JSON.stringify(e.inputRaw)),localStorage.setItem("programmeStyle",JSON.stringify(e.style));{(a=document.querySelector("#styleHTML"))==null||a.remove();const t=document.createElement("style");t.setAttribute("type","text/css"),t.id="styleHTML",t.innerHTML=e.style.customCSS,document.body.append(t)}});function Z(o){return b.test(o)?{fontSize:"18px",justifyContent:"center"}:{}}function z(o){!x.value&&o.detail.inACTCombat&&(_=setInterval(()=>{T()},1e3)),x.value&&!o.detail.inACTCombat&&(clearInterval(_),H()),x.value=o.detail.inACTCombat}function U(){H(),I=setInterval(()=>{T()},100)}function H(){clearInterval(I),x.value=!1,d.value=0,r.value=0,S.value=e.style.lineHeight}function T(){var a;d.value++;for(let t=0;t<e.list.length;t++)if(Number.parseInt(((a=e.list[t].timeSeconds)==null?void 0:a.toString())??"-1")===d.value){S.value=e.style.lineHeight*(t+1),(t>1&&b.test(e.list[t-1].text)||r.value+650-e.style.lineHeight*2.5<e.style.lineHeight*(t+1))&&(r.value=o(e.style.lineHeight*(t-2.5)));break}function o(t){const s=document.querySelector("#main>ul").scrollHeight-650+e.style.lineHeight*1.5;return t>=s&&(t=s),t}}function F(){confirm("确定恢复模板字符串为默认设置吗？")&&(localStorage.removeItem("programmeData"),w())}function J(){confirm("确定恢复自定义CSS为默认设置吗？")&&(localStorage.removeItem("programmeStyle"),w())}return(o,a)=>(f(),C(N,null,[l("div",{id:"warpper",style:m(n(B))},[l("header",null,[lt,l("article",null,v(n(D)),1)]),l("main",{id:"main",style:m({overflowY:n(h)?"auto":"hidden"})},[(f(),C("svg",{xmlns:"http://www.w3.org/2000/svg",width:"35",viewBox:"0 0 38 22",fill:"none",class:"icon position",style:m({top:`${n(S)-n(r)}px`,opacity:n(d)})},rt,4)),l("ul",{style:m({transform:`translateY(${-n(r)}px)`})},[(f(!0),C(N,null,G(n(e).list,(t,s)=>(f(),C("li",{key:s,style:m(Object.assign(Z(t.text),{height:`${n(e).style.lineHeight}px`})),class:X([b.test(t.text)?"stage":"normal",t.className])},[c(v(t.text)+" ",1),i(l("span",{class:"auxiliary"},v(t.timeFormat),513),[[O,t.timeSeconds&&t.timeSeconds>0&&t.timeFormat]])],6))),128))],4),l("span",{style:m({width:`${n($)}px`,top:`${n(e).style.lineHeight+25*1.5-5-n(r)}px`})},v("-".repeat(299)),5)],4)],4),i(l("aside",it,[l("p",null,[l("button",{onClick:a[0]||(a[0]=t=>U())}," 10倍速测试 ")]),l("p",null,[c(" 正文模板 "),l("button",{onClick:a[1]||(a[1]=t=>F())}," 恢复默认正文 ")]),i(l("textarea",{"onUpdate:modelValue":a[2]||(a[2]=t=>n(e).inputRaw=t),cols:"80",rows:"20"},null,512),[[y,n(e).inputRaw]]),l("p",null,[c(" 总缩放"),i(l("input",{"onUpdate:modelValue":a[3]||(a[3]=t=>n(e).style.scale=t),type:"number",step:"0.1",min:"0.5"},null,512),[[y,n(e).style.scale]])]),l("p",null,[c(" 每行高"),i(l("input",{"onUpdate:modelValue":a[4]||(a[4]=t=>n(e).style.lineHeight=t),type:"number",step:"1",min:"20"},null,512),[[y,n(e).style.lineHeight]])]),l("p",null,[c(" 允许用户滚动"),i(l("input",{"onUpdate:modelValue":a[5]||(a[5]=t=>K(h)?h.value=t:null),type:"checkbox"},null,512),[[Q,n(h)]]),c("（该选项不会保存） ")]),l("p",null,[c(" 自定义CSS "),l("button",{onClick:a[6]||(a[6]=t=>J())}," 恢复默认CSS ")]),i(l("textarea",{"onUpdate:modelValue":a[7]||(a[7]=t=>n(e).style.customCSS=t),cols:"80",rows:"30"},null,512),[[y,n(e).style.customCSS]])],512),[[O,n(k)]])],64))}});const ut=st(ct,[["__scopeId","data-v-4bdca458"]]);export{ut as default};
